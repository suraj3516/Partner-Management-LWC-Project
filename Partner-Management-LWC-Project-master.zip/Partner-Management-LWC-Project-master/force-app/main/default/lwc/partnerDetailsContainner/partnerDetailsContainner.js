import { LightningElement, wire } from 'lwc';




export default class PartnerDetailsContainner extends LightningElement {

}