import { LightningElement, wire, api } from 'lwc';



export default class AddPartnerReview extends LightningElement {
    

   

}